// ✅ DeepfakeResult.kt
package com.example.deepfakeface.model

import com.google.gson.annotations.SerializedName

data class DeepfakeResult(
    val isFake: Boolean,
    val confidence: Float,
    val message: String
)

// ✅ UploadResponse.kt




data class UploadResponse(
    val status: String,
    val message: String?,
    val result: String?,           // Should match backend key exactly
    val fake_percentage: Double?   // Also exact match needed
)



// ✅ SignupResponse.kt


data class SignupResponse(
    val success: Boolean,
    val message: String,
    val userId: String? = null
)

// ✅ LoginResponse.kt


data class LoginResponse(
    val success: Boolean,
    val message: String,
    val token: String? = null
)

// ✅ ResultResponse.kt


data class ResultResponse(
    val success: Boolean,
    val results: List<DeepfakeResult>
)
