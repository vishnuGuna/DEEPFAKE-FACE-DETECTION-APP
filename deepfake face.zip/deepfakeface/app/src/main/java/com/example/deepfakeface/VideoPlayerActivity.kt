package com.example.deepfakeface

import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import android.widget.VideoView
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.sp
import androidx.compose.ui.Alignment

class VideoPlayerActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val videoUri = intent.getStringExtra("videoUri")

        setContent {
            Surface(
                modifier = Modifier.fillMaxSize(),
                color = MaterialTheme.colorScheme.background
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Brush.verticalGradient(listOf(Color.Black, Color.DarkGray)))
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {

                        videoUri?.let {
                            val uri = Uri.parse(it)
                            AndroidView(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(300.dp)
                                    .background(Color.Black),
                                factory = { context ->
                                    VideoView(context).apply {
                                        setVideoURI(uri)
                                        setOnPreparedListener { mediaPlayer ->
                                            mediaPlayer.setVolume(1f, 1f)
                                            mediaPlayer.isLooping = true
                                            start()
                                        }
                                        setOnErrorListener { _, what, extra ->
                                            Toast.makeText(context, "Video playback error", Toast.LENGTH_SHORT).show()
                                            true
                                        }
                                    }
                                }
                            )
                        } ?: Text("Invalid video path", color = Color.White)


                        Spacer(modifier = Modifier.height(16.dp))

                        // 🔙 Back Button
                        Button(
                            onClick = { finish() },
                            colors = ButtonDefaults.buttonColors(containerColor = Color.Red),
                            modifier = Modifier
                                .fillMaxWidth(0.8f)
                                .height(50.dp)
                        ) {
                            Text(text = "Back", fontSize = 18.sp)
                        }
                    }
                }
            }
        }
    }
}