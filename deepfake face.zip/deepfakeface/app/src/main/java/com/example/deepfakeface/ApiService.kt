package com.example.deepfakeface.api
import com.example.deepfakeface.model.ImageUploadResponse
import com.example.deepfakeface.model.*
import com.example.deepfakeface.model.DeepfakeResult
import okhttp3.MultipartBody
import retrofit2.Response
import retrofit2.http.*
import retrofit2.Call
import retrofit2.http.Multipart
import retrofit2.http.POST
import retrofit2.http.Part


interface ApiService {

    // Video upload API - multipart form data with video file
    @Multipart
    @POST("analysis.php")
    suspend fun uploadVideo(
        @Part video: MultipartBody.Part
    ): Response<UploadResponse>

    // Image upload API (if you have one)
    @Multipart
    @POST("upload.php")
    suspend fun uploadImage(
        @Part image: MultipartBody.Part
    ): Response<ImageUploadResponse>

    // Signup API - form-urlencoded POST with user details
    @FormUrlEncoded
    @POST("signup.php")
    suspend fun signup(
        @Field("name") name: String,
        @Field("email") email: String,
        @Field("password") password: String,
        @Field("designation") designation: String
    ): Response<SignupResponse>

    // Login API - form-urlencoded POST with email and password
    @FormUrlEncoded
    @POST("login.php")
    suspend fun login(
        @Field("email") email: String,
        @Field("password") password: String
    ): Response<LoginResponse>

    // Fetch result API by video/image ID or user ID
    @GET("get_results.php")
    suspend fun getResults(
        @Query("user_id") userId: String
    ): Response<ResultResponse>

    // Any other APIs your backend provides...

}
