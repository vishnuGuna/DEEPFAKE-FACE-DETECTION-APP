package com.example.deepfakeface.model

data class ImageUploadResponse(
    val status: String,
    val file_path: String?,
    val result: String?,
    val confidence: Double?,
    val message: String? // for error messages when status is error
)
