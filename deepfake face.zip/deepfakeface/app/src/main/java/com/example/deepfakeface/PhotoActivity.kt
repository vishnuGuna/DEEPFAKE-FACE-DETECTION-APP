package com.example.deepfakeface

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.rememberAsyncImagePainter
import com.example.deepfakeface.api.RetrofitClient
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.asRequestBody
import java.io.File

class PhotoActivity : ComponentActivity() {
    private var selectedImageUri: Uri? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            val context = LocalContext.current

            val imagePickerLauncher = rememberLauncherForActivityResult(
                contract = ActivityResultContracts.GetContent()
            ) { uri: Uri? ->
                selectedImageUri = uri
                uri?.let {
                    Toast.makeText(context, "Image selected", Toast.LENGTH_SHORT).show()
                }
            }

            Surface(
                modifier = Modifier.fillMaxSize(),
                color = MaterialTheme.colorScheme.background
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Brush.verticalGradient(listOf(Color.Black, Color.DarkGray)))
                ) {
                    // Back Button
                    IconButton(
                        onClick = { finish() },
                        modifier = Modifier
                            .padding(16.dp)
                            .align(Alignment.TopStart)
                    ) {
                        Icon(
                            painter = painterResource(id = R.drawable.img_1),
                            contentDescription = "Back",
                            tint = Color.White,
                            modifier = Modifier.size(40.dp)
                        )
                    }


                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {

                        // Show previewed image
                        selectedImageUri?.let {
                            Image(
                                painter = rememberAsyncImagePainter(it),
                                contentDescription = null,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(300.dp)
                                    .padding(8.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(20.dp))

                        // Upload Photo Button
                        Button(
                            onClick = { imagePickerLauncher.launch("image/*") },
                            colors = ButtonDefaults.buttonColors(containerColor = Color.LightGray),
                            shape = RoundedCornerShape(50.dp),
                            modifier = Modifier
                                .fillMaxWidth(0.8f)
                                .height(70.dp)
                                .padding(8.dp)



                        ) {
                            Text("Upload Photo")
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Click to Preview Button (centered)
                        Button(
                            onClick = {
                                selectedImageUri?.let {
                                    val intent = Intent(context, ImagePreviewActivity::class.java).apply {
                                        putExtra("imageUri", it.toString())
                                        putExtra("previewOnly", true)
                                    }
                                    startActivity(intent)
                                } ?: Toast.makeText(context, "Please select an image first", Toast.LENGTH_SHORT).show()
                            },
                            shape = RoundedCornerShape(50.dp),
                            modifier = Modifier
                                .fillMaxWidth(0.8f)
                                .padding(8.dp)
                                .height(50.dp),

                            colors = ButtonDefaults.buttonColors(containerColor = Color.Blue)
                        ) {
                            Text("Click here to preview")
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Analyze Image Button
                        Button(
                            onClick = {
                                selectedImageUri?.let { uri ->
                                    val file = File(getRealPathFromURI(uri))
                                    val requestFile = file.asRequestBody("image/*".toMediaTypeOrNull())
                                    val body = MultipartBody.Part.createFormData("image", file.name, requestFile)

                                    CoroutineScope(Dispatchers.IO).launch {
                                        try {
                                            val response = RetrofitClient.api.uploadImage(body)
                                            if (response.isSuccessful) {
                                                val res = response.body()
                                                if (res?.status == "success") {
                                                    val intent = Intent(context, ImagePreviewActivity::class.java).apply {
                                                        putExtra("imageUri", uri.toString())
                                                        putExtra("result", res.result)
                                                        putExtra("confidence", res.confidence)
                                                        putExtra("previewOnly", false)
                                                    }
                                                    startActivity(intent)
                                                } else {
                                                    runOnUiThread {
                                                        Toast.makeText(context, "Detection failed: ${res?.message}", Toast.LENGTH_SHORT).show()
                                                    }
                                                }
                                            } else {
                                                runOnUiThread {
                                                    Toast.makeText(context, "Server error", Toast.LENGTH_SHORT).show()
                                                }
                                            }
                                        } catch (e: Exception) {
                                            runOnUiThread {
                                                Toast.makeText(context, "Error: ${e.message}", Toast.LENGTH_LONG).show()
                                            }
                                        }
                                    }
                                } ?: Toast.makeText(context, "Please select an image first", Toast.LENGTH_SHORT).show()
                            },
                            shape = RoundedCornerShape(50.dp),
                            modifier = Modifier
                                .fillMaxWidth(0.8f)
                                .padding(8.dp)
                                .height(50.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color.Green)
                        ) {
                            Text("Analyze Image")
                        }

                        Spacer(modifier = Modifier.height(24.dp))


                    }
                }
            }
        }
    }

    private fun getRealPathFromURI(uri: Uri): String {
        val projection = arrayOf(MediaStore.Images.Media.DATA)
        contentResolver.query(uri, projection, null, null, null)?.use { cursor ->
            val columnIndex = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA)
            cursor.moveToFirst()
            return cursor.getString(columnIndex)
        }
        throw IllegalArgumentException("Unable to get image path")
    }
}
