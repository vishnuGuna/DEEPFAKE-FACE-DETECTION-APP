package com.example.deepfakeface

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.deepfakeface.api.RetrofitInstance
import com.example.deepfakeface.model.DeepfakeResult
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.asRequestBody
import java.io.File
import com.example.deepfakeface.ui.theme.DeepfakeFaceTheme


class VideoActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val videoUri = mutableStateOf<String?>(null)
        val isUploading = mutableStateOf(false)
        val detectionResult = mutableStateOf<String?>(null)
        val confidence = mutableStateOf<Double?>(null)

        val pickVideo = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            uri?.let {
                videoUri.value = it.toString()
                detectionResult.value = null
                confidence.value = null
            }
        }

        setContent {
            val context = LocalContext.current

            DeepfakeFaceTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Brush.verticalGradient(listOf(Color.DarkGray, Color.Black)))
                    ) {
                        // Back Button
                        IconButton(
                            onClick = { finish() },
                            modifier = Modifier
                                .padding(16.dp)
                                .align(Alignment.TopStart)
                        ) {
                            Icon(
                                painter = painterResource(id = R.drawable.img_1),
                                contentDescription = "Back",
                                tint = Color.White,
                                modifier = Modifier.size(40.dp)
                            )
                        }

                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(top = 72.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            // Upload video button
                            Button(
                                onClick = { pickVideo.launch("video/*") },
                                colors = ButtonDefaults.buttonColors(containerColor = Color.LightGray),
                                shape = RoundedCornerShape(50.dp),
                                modifier = Modifier
                                    .fillMaxWidth(0.8f)
                                    .height(70.dp)
                                    .padding(8.dp),
                                enabled = !isUploading.value
                            ) {
                                Text(text = "Upload video", fontSize = 20.sp, color = Color.Black)
                            }

                            // Play video button (if video selected)
                            videoUri.value?.let { uriString ->
                                Spacer(modifier = Modifier.height(16.dp))

                                Button(
                                    onClick = {
                                        val intent = Intent(context, VideoPlayerActivity::class.java)
                                        intent.putExtra("videoUri", uriString)
                                        context.startActivity(intent)
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color.Blue),
                                    shape = RoundedCornerShape(50.dp),
                                    modifier = Modifier
                                        .fillMaxWidth(0.8f)
                                        .height(70.dp)
                                        .padding(8.dp),
                                    enabled = !isUploading.value
                                ) {
                                    Text(text = "Click here to play", fontSize = 20.sp, color = Color.White)
                                }

                                Spacer(modifier = Modifier.height(16.dp))

                                // Upload to backend button
                                Button(
                                    onClick = {
                                        videoUri.value?.let { uri ->
                                            uploadVideoFile(uri, context, isUploading, detectionResult, confidence)
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color.Green),
                                    shape = RoundedCornerShape(50.dp),
                                    modifier = Modifier
                                        .fillMaxWidth(0.8f)
                                        .height(70.dp)
                                        .padding(8.dp),
                                    enabled = !isUploading.value
                                ) {
                                    Text(text = if (isUploading.value) "Uploading..." else "Analyze Video", fontSize = 20.sp, color = Color.White)
                                }
                            }

                            Spacer(modifier = Modifier.height(24.dp))

                            // Show detection result
                            detectionResult.value?.let { resultText ->
                                Text(
                                    text = "Result: $resultText",
                                    color = Color.White,
                                    fontSize = 22.sp
                                )
                            }

                            confidence.value?.let { conf ->
                                Text(
                                    text = "Confidence: ${String.format("%.2f", conf)}%",
                                    color = Color.White,
                                    fontSize = 18.sp
                                )
                            }
                        }
                    }
                }
            }
        }
    }
    private fun uploadVideoFile(
        uriString: String,
        context: android.content.Context,
        isUploading: MutableState<Boolean>,
        detectionResult: MutableState<String?>,
        confidence: MutableState<Double?>
    ) {
        val uri = Uri.parse(uriString)
        val contentResolver = context.contentResolver

        // Copy video to cache file for uploading
        val inputStream = contentResolver.openInputStream(uri) ?: run {
            Toast.makeText(context, "Unable to open video file", Toast.LENGTH_SHORT).show()
            return
        }
        val tempFile = File(context.cacheDir, "upload_video.mp4")
        tempFile.outputStream().use { outputStream ->
            inputStream.copyTo(outputStream)
        }

        val requestFile = tempFile.asRequestBody("video/mp4".toMediaTypeOrNull())
        val body = MultipartBody.Part.createFormData("video", tempFile.name, requestFile)

        isUploading.value = true

        CoroutineScope(Dispatchers.IO).launch {
            try {
                val response = RetrofitInstance.api.uploadVideo(body)

                withContext(Dispatchers.Main) {
                    isUploading.value = false

                    if (response.isSuccessful) {
                        val result = response.body()
                        if (result?.status == "success") {
                            detectionResult.value = result.result ?: "Unknown"
                            confidence.value = result.fake_percentage ?: 0.0
                        } else {
                            Toast.makeText(context, result?.message ?: "Detection failed", Toast.LENGTH_SHORT).show()
                        }
                    } else {
                        Toast.makeText(context, "Upload failed: ${response.message()}", Toast.LENGTH_SHORT).show()
                    }
                }

            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    isUploading.value = false
                    Toast.makeText(context, "Upload failed: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
}
