// Ensure the package matches the folder structure
package com.example.deepfakeface

import android.content.Intent  // Import for navigation
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.activity.compose.LocalOnBackPressedDispatcherOwner
import com.example.deepfakeface.ui.theme.DeepfakeFaceTheme

class WelcomeActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            DeepfakeFaceTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    WelcomeScreen(
                        onNavigateToLogin = {
                            val intent = Intent(this, LoginActivity::class.java)
                            startActivity(intent)
                        },
                        onNavigateToSignUp = {
                            val intent = Intent(this, SignUpActivity::class.java)
                            startActivity(intent)
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun WelcomeScreen(
    onNavigateToLogin: () -> Unit,
    onNavigateToSignUp: () -> Unit
) {
    val backDispatcher = LocalOnBackPressedDispatcherOwner.current?.onBackPressedDispatcher

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(Color.DarkGray, Color.Black)
                )
            )
            .padding(16.dp)
    ) {

        // Back Button
        IconButton(
            onClick = { backDispatcher?.onBackPressed() },
            modifier = Modifier
                .size(48.dp)
                .align(Alignment.TopStart)
                .padding(8.dp)
        ) {
            Icon(
                painter = painterResource(id = R.drawable.img_1),  // Back icon
                contentDescription = "Back Button",
                tint = Color.White
            )
        }

        Column(
            modifier = Modifier
                .fillMaxSize(),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {

            // Logo Image
            Image(
                painter = painterResource(id = R.drawable.img),  // Place logo in drawable folder
                contentDescription = "Deepfake Logo",
                modifier = Modifier
                    .size(150.dp)
                    .padding(16.dp),
                contentScale = ContentScale.Fit
            )

            // App Title
            Text(
                text = "Deepfake Face App",
                color = Color.White,
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(vertical = 24.dp)
            )

            // Log In Button with Navigation to LoginActivity
            Button(
                onClick = { onNavigateToLogin() },  // Navigate to LoginActivity
                modifier = Modifier
                    .fillMaxWidth(0.8f)
                    .height(75.dp)
                    .padding(vertical = 8.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color.Black),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("Log In", color = Color.White, fontSize = 18.sp)
            }

            // Sign Up Button with Navigation to SignUpActivity
            Button(
                onClick = { onNavigateToSignUp() },  // Navigate to SignUpActivity
                modifier = Modifier
                    .fillMaxWidth(0.8f)
                    .height(75.dp)
                    .padding(vertical = 8.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color.Black),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("Sign up", color = Color.White, fontSize = 18.sp)
            }
        }
    }
}
