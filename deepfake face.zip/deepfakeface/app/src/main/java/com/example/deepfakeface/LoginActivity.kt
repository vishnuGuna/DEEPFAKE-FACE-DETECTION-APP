package com.example.deepfakeface

import android.content.Intent  // Import for navigation
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext


import com.example.deepfakeface.ui.theme.DeepfakeFaceTheme

class LoginActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            DeepfakeFaceTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    LoginScreen(
                        onNavigateToSignUp = {
                            val intent = Intent(this, SignUpActivity::class.java)
                            startActivity(intent)
                        },
                        onNavigateToFilePath = {
                            val intent = Intent(this, FilePathActivity::class.java)
                            startActivity(intent)
                        },
                        onBackPressed = { finish() }  // Back navigation
                    )
                }
            }
        }
    }
}

@Composable
fun LoginScreen(
    onNavigateToSignUp: () -> Unit,
    onNavigateToFilePath: () -> Unit,
    onBackPressed: () -> Unit
) {
    val context = LocalContext.current
    var name by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(Color.DarkGray, Color.Black)
                )
            )
            .padding(16.dp)
    ) {

        // Back Button with Image
        IconButton(
            onClick = { onBackPressed() },
            modifier = Modifier
                .padding(16.dp)
                .align(Alignment.TopStart)
        ) {
            Icon(
                painter = painterResource(id = R.drawable.img_1),  // Use uploaded image
                contentDescription = "Back",
                tint = Color.White,
                modifier = Modifier.size(48.dp)
            )
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {

            // Welcome Text
            Text(
                text = "Hi,\nWelcome! 👋",
                fontSize = 32.sp,
                color = Color.White,
                fontWeight = FontWeight.Bold,
                modifier = Modifier
                    .padding(bottom = 8.dp)
                    .align(Alignment.CenterHorizontally)
            )

            // Log in Text
            Text(
                text = "Log in",
                fontSize = 26.sp,
                color = Color.White,
                fontWeight = FontWeight.Bold,
                modifier = Modifier
                    .padding(bottom = 32.dp)
                    .align(Alignment.CenterHorizontally)
            )

            // Username Field
            Text(
                text = "Username",
                color = Color.White,
                fontWeight = FontWeight.Bold,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 4.dp)
            )
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("Your username") },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Color.White,
                    unfocusedBorderColor = Color.Gray,
                    cursorColor = Color.White,
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                )
            )

            // Password Field
            Text(
                text = "Password",
                color = Color.White,
                fontWeight = FontWeight.Bold,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 4.dp)
            )
            OutlinedTextField(
                value = password,
                onValueChange = { password = it },
                label = { Text("Password") },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                trailingIcon = {
                    IconButton(onClick = { passwordVisible = !passwordVisible }) {
                        Icon(
                            painter = painterResource(
                                id = if (passwordVisible)
                                    android.R.drawable.ic_menu_view
                                else
                                    android.R.drawable.ic_menu_close_clear_cancel
                            ),
                            contentDescription = "Toggle password visibility",
                            tint = Color.White
                        )
                    }
                },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Color.White,
                    unfocusedBorderColor = Color.Gray,
                    cursorColor = Color.White,
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                )
            )

            Spacer(modifier = Modifier.height(16.dp))


            // Log In Button (Navigates to FilePathActivity)
            Button(
                onClick = {
                    if (name.isBlank() || password.isBlank()) {
                        Toast.makeText(
                            context,
                            "Please enter both username and password",
                            Toast.LENGTH_SHORT
                        ).show()
                    } else {
                        val apiUrl = "http://192.168.14.42/login.php?name=${name}&password=${password}"

                        android.util.Log.d("LoginURL", apiUrl)

                        Thread {
                            try {
                                val url = java.net.URL(apiUrl)
                                val connection = url.openConnection() as java.net.HttpURLConnection
                                connection.requestMethod = "GET"

                                val responseCode = connection.responseCode
                                val inputStream = if (responseCode == 200) connection.inputStream else connection.errorStream
                                val response = inputStream.bufferedReader().use { it.readText() }

                                android.util.Log.d("LoginResponse", response)

                                val jsonResponse = org.json.JSONObject(response)
                                val status = jsonResponse.getString("status")
                                val message = jsonResponse.getString("message")

                                (context as android.app.Activity).runOnUiThread {
                                    Toast.makeText(context, message, Toast.LENGTH_SHORT).show()

                                    if (status == "success") {
                                        onNavigateToFilePath()  // Navigate to FilePathActivity
                                    }
                                }
                            } catch (e: Exception) {
                                e.printStackTrace()
                                (context as android.app.Activity).runOnUiThread {
                                    Toast.makeText(context, "Login failed: ${e.message}", Toast.LENGTH_LONG).show()
                                }
                            }
                        }.start()
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color.Black),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(65.dp)
                    .padding(vertical = 8.dp)
            ) {
                Text(text = "Log in", color = Color.White, fontSize = 18.sp)
            }





            Spacer(modifier = Modifier.height(24.dp))

            // Sign-up Navigation Text
            Text(
                text = "Don’t have an account? Sign up",
                color = Color.White,
                fontSize = 14.sp,
                modifier = Modifier
                    .clickable { onNavigateToSignUp() }
                    .padding(top = 8.dp)
            )
        }
    }
    }

