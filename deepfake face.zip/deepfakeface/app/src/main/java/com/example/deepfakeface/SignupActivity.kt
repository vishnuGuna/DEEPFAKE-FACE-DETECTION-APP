package com.example.deepfakeface

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.util.Patterns
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.deepfakeface.ui.theme.DeepfakeFaceTheme
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import okhttp3.*
import java.io.IOException

class SignUpActivity : ComponentActivity() {
    private val client = OkHttpClient()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            DeepfakeFaceTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    SignUpScreen(
                        onNavigateToLogin = {
                            startActivity(Intent(this, LoginActivity::class.java))
                        },
                        onBackPressed = { finish() },
                        onSignUp = { name, email, password, confirmPassword ->
                            if (name.isBlank() || email.isBlank() || password.isBlank() || confirmPassword.isBlank()) {
                                Toast.makeText(this, "All fields are required", Toast.LENGTH_SHORT).show()
                                return@SignUpScreen
                            }

                            if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                                Toast.makeText(this, "Invalid email format", Toast.LENGTH_SHORT).show()
                                return@SignUpScreen
                            }

                            if (password != confirmPassword) {
                                Toast.makeText(this, "Passwords do not match", Toast.LENGTH_SHORT).show()
                                return@SignUpScreen
                            }

                            CoroutineScope(Dispatchers.IO).launch {
                                val result = signUp(name, email, password, confirmPassword)
                                runOnUiThread {
                                    Toast.makeText(this@SignUpActivity, "${result.status}: ${result.message}", Toast.LENGTH_LONG).show()


                                    if (result.status == "success") {
                                        startActivity(Intent(this@SignUpActivity, WelcomeActivity::class.java))
                                        finish()
                                    }
                                }
                            }
                        }
                    )
                }
            }
        }
    }

    private suspend fun signUp(name: String, email: String, password: String, confirmPassword: String): ApiResponse {
        val formBody = FormBody.Builder()
            .add("name", name)
            .add("email", email)
            .add("password", password)
            .add("confirmPassword", confirmPassword)
            .build()

        val request = Request.Builder()
            .url("http://192.168.14.42/signup.php") // Replace with your backend IP
            .post(formBody)
            .build()

        return try {
            val response = client.newCall(request).execute()
            val body = response.body?.string()

            Log.d("SignUpDebug", "Response Code: ${response.code}")
            Log.d("SignUpDebug", "Raw response body: $body")

            if (body != null) {
                val gson = com.google.gson.Gson()
                gson.fromJson(body, ApiResponse::class.java)
            } else {
                ApiResponse("error", "Empty response from server")
            }
        } catch (e: IOException) {
            Log.e("SignUpDebug", "Exception: ${e.message}")
            ApiResponse("error", "Network error: ${e.message}")
        }
    }
}

data class ApiResponse(
    val status: String,
    val message: String?
)

@Composable
fun SignUpScreen(
    onNavigateToLogin: () -> Unit,
    onBackPressed: () -> Unit,
    onSignUp: (name: String, email: String, password: String, confirmPassword: String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }
    var confirmPasswordVisible by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color.DarkGray, Color.Black)))
            .padding(16.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Sign Up", fontSize = 30.sp, color = Color.White, fontWeight = FontWeight.Bold)

        Spacer(Modifier.height(16.dp))

        OutlinedTextField(
            value = name,
            onValueChange = { name = it },
            label = { Text("Name") },
            modifier = Modifier.fillMaxWidth(0.85f),
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = Color.White, unfocusedTextColor = Color.White
            )
        )

        OutlinedTextField(
            value = email,
            onValueChange = { email = it },
            label = { Text("Email") },
            modifier = Modifier.fillMaxWidth(0.85f),
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = Color.White, unfocusedTextColor = Color.White
            )
        )

        OutlinedTextField(
            value = password,
            onValueChange = { password = it },
            label = { Text("Password") },
            visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth(0.85f),
            trailingIcon = {
                IconButton(onClick = { passwordVisible = !passwordVisible }) {
                    Icon(painterResource(id = android.R.drawable.ic_menu_view), contentDescription = null)
                }
            },
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = Color.White, unfocusedTextColor = Color.White
            )
        )

        OutlinedTextField(
            value = confirmPassword,
            onValueChange = { confirmPassword = it },
            label = { Text("Confirm Password") },
            visualTransformation = if (confirmPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth(0.85f),
            trailingIcon = {
                IconButton(onClick = { confirmPasswordVisible = !confirmPasswordVisible }) {
                    Icon(painterResource(id = android.R.drawable.ic_menu_view), contentDescription = null)
                }
            },
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = Color.White, unfocusedTextColor = Color.White
            )
        )

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = { onSignUp(name.trim(), email.trim(), password, confirmPassword) },
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier.fillMaxWidth(0.85f)
        ) {
            Text("Sign Up")
        }

        Text(
            text = "Already have an account? Log In",
            color = Color.White,
            modifier = Modifier
                .padding(top = 12.dp)
                .clickable { onNavigateToLogin() }
        )
    }
}
