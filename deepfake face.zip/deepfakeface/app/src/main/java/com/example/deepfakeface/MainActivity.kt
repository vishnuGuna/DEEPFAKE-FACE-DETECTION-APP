package com.example.deepfakeface

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.tooling.preview.Preview
import com.example.deepfakeface.ui.theme.DeepfakeFaceTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            DeepfakeFaceTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    GetStartedScreen(
                        modifier = Modifier.padding(innerPadding),
                        onGetStartedClick = {
                            // Navigate to WelcomeActivity
                            val intent = Intent(this, WelcomeActivity::class.java)
                            startActivity(intent)
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun GetStartedScreen(
    modifier: Modifier = Modifier,
    onGetStartedClick: () -> Unit  // Click event callback
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Black)
            .padding(16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Face Authentication Image
            Image(
                painter = painterResource(id = R.drawable.img),  // Ensure image is in res/drawable
                contentDescription = "Face Authentication",
                modifier = Modifier
                    .size(200.dp)
                    .padding(bottom = 32.dp),
                contentScale = ContentScale.Fit
            )

            // Title Text
            Text(
                text = "FACE AUTHENTICATION",
                color = Color.White,
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 24.dp)
            )

            // Get Started Button with Navigation
            Button(
                onClick = onGetStartedClick,   // Navigate to WelcomeActivity
                modifier = Modifier
                    .fillMaxWidth(0.7f)
                    .height(50.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color.LightGray),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text(text = "Let’s get started", color = Color.Black, fontSize = 16.sp)
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun PreviewGetStartedScreen() {
    DeepfakeFaceTheme {
        GetStartedScreen(onGetStartedClick = {})
    }
}
